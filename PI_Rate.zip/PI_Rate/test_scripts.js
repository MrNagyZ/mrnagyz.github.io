$.get('file/words.txt', function(data) {
    alert(data)
 }, 'text');